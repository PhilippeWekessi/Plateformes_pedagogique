document.getElementById("formAffectation").addEventListener("submit", function(e) {
    e.preventDefault();

    const formData = new FormData(this);

    fetch("../backend/affectation_formateur.php", {
        method: "POST",
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        const msg = document.getElementById("message");
        msg.textContent = data.message;
        msg.className = data.success ? "success" : "error";
    });
});
