<?php
require_once "../../config/database.php";

header("Content-Type: application/json");

$formateur_id = $_POST['formateur_id'] ?? null;
$espace_id = $_POST['espace_id'] ?? null;

if (!$formateur_id || !$espace_id) {
    echo json_encode([
        "success" => false,
        "message" => "Informations manquantes"
    ]);
    exit;
}

// Vérifier si déjà affecté
$check = $pdo->prepare("
    SELECT id FROM affectation_formateur_espace
    WHERE formateur_id = ? AND espace_id = ?
");
$check->execute([$formateur_id, $espace_id]);

if ($check->rowCount() > 0) {
    echo json_encode([
        "success" => false,
        "message" => "Formateur déjà affecté à cet espace pédagogique"
    ]);
    exit;
}

// Insertion
$stmt = $pdo->prepare("
    INSERT INTO affectation_formateur_espace (formateur_id, espace_id)
    VALUES (?, ?)
");

$stmt->execute([$formateur_id, $espace_id]);

echo json_encode([
    "success" => true,
    "message" => "Formateur affecté avec succès"
]);
