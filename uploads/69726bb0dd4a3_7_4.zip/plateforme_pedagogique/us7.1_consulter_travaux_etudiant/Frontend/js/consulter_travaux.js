document.addEventListener("DOMContentLoaded", () => {

    // ⚠️ normalement récupéré via session
    const etudiant_id = 1;

    fetch("../backend/lister_travaux_etudiant.php?etudiant_id=" + etudiant_id)
        .then(res => res.json())
        .then(data => {
            const tbody = document.querySelector("#tableTravaux tbody");
            const message = document.getElementById("message");

            if (!data.success) {
                message.textContent = data.message;
                return;
            }

            if (data.travaux.length === 0) {
                message.textContent = "Aucun travail assigné";
                return;
            }

            data.travaux.forEach(travail => {
                const tr = document.createElement("tr");

                tr.innerHTML = `
                    <td>${travail.titre}</td>
                    <td>${travail.type}</td>
                    <td>${travail.consignes}</td>
                    <td>${travail.date_limite}</td>
                    <td>${travail.statut}</td>
                `;

                tbody.appendChild(tr);
            });
        })
        .catch(() => {
            document.getElementById("message").textContent =
                "Erreur réseau ou serveur";
        });
});
