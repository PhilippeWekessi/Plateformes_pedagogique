<?php
header("Content-Type: application/json");
require_once "../../config/database.php";
require_once "verifier_etudiant.php";

$etudiant_id = $_GET['etudiant_id'] ?? null;

if (!$etudiant_id) {
    echo json_encode([
        "success" => false,
        "message" => "Étudiant non fourni"
    ]);
    exit;
}

if (!verifierEtudiant($pdo, $etudiant_id)) {
    echo json_encode([
        "success" => false,
        "message" => "Étudiant introuvable"
    ]);
    exit;
}

$sql = "
SELECT t.titre, t.type, t.consignes, t.date_limite,
       IF(l.id IS NULL, 'Non livré', 'Livré') AS statut
FROM travaux t
JOIN travaux_assignes ta ON ta.travail_id = t.id
LEFT JOIN livraisons l ON l.travail_id = t.id AND l.etudiant_id = ?
WHERE ta.etudiant_id = ?
";

$stmt = $pdo->prepare($sql);
$stmt->execute([$etudiant_id, $etudiant_id]);
$travaux = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode([
    "success" => true,
    "travaux" => $travaux
]);
