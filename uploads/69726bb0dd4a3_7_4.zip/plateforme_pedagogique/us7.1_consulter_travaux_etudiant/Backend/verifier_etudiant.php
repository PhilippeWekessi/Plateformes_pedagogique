<?php
function verifierEtudiant($pdo, $etudiant_id) {
    $stmt = $pdo->prepare("SELECT id FROM etudiants WHERE id = ?");
    $stmt->execute([$etudiant_id]);
    return $stmt->fetch();
}
