document.getElementById("formLivraison").addEventListener("submit", function(e) {
    e.preventDefault();

    const form = e.target;
    const formData = new FormData(form);
    const message = document.getElementById("message");

    fetch("../backend/livrer_travail.php", {
        method: "POST",
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            message.textContent = data.message;
            message.className = "success";
            form.reset();
        } else {
            message.textContent = data.message;
            message.className = "error";
        }
    })
    .catch(() => {
        message.textContent = "Erreur serveur, veuillez réessayer.";
        message.className = "error";
    });
});
