<?php
require_once "../../config/database.php";

$travail_id = $_GET['travail_id'] ?? null;
$etudiant_id = 1; // remplacer par ID étudiant connecté

if ($travail_id) {
    $stmt = $conn->prepare("SELECT * FROM livraisons WHERE travail_id = ? AND etudiant_id = ?");
    $stmt->execute([$travail_id, $etudiant_id]);
    if ($stmt->rowCount() > 0) {
        echo json_encode(['livre' => true]);
    } else {
        echo json_encode(['livre' => false]);
    }
}
