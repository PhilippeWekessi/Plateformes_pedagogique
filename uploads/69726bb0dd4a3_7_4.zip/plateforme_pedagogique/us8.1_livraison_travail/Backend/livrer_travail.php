<?php
header('Content-Type: application/json');
require_once "../../config/database.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $travail_id = $_POST['travail_id'];
    $fichier = $_FILES['fichier'];

    if (!$travail_id || !$fichier) {
        echo json_encode(['success' => false, 'message' => 'Tous les champs sont obligatoires.']);
        exit;
    }

    $ext = strtolower(pathinfo($fichier['name'], PATHINFO_EXTENSION));
    $allowed = ['pdf', 'doc', 'docx', 'zip'];

    if (!in_array($ext, $allowed)) {
        echo json_encode(['success' => false, 'message' => 'Format de fichier non autorisé.']);
        exit;
    }

    // Vérifier si le travail a déjà été livré
    $stmt = $conn->prepare("SELECT * FROM livraisons WHERE travail_id = ? AND etudiant_id = ?");
    $stmt->execute([$travail_id, 1]); // ici 1 = ID étudiant simulé, remplacer par la session
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => false, 'message' => 'Travail déjà livré']);
        exit;
    }

    $uploadDir = '../uploads/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
    $filePath = $uploadDir . basename($fichier['name']);

    if (move_uploaded_file($fichier['tmp_name'], $filePath)) {
        $stmt = $conn->prepare("INSERT INTO livraisons (travail_id, etudiant_id, fichier, date_livraison) VALUES (?, ?, ?, NOW())");
        $stmt->execute([$travail_id, 1, $fichier['name']]); // remplacer 1 par ID étudiant connecté

        echo json_encode(['success' => true, 'message' => 'Travail livré avec succès']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Erreur lors de l’upload du fichier']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée']);
}
