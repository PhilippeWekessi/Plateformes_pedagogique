<?php
require_once "../../config/database.php";

$email = $_GET['email'];
$promotion_id = $_GET['promotion_id'];

$stmt = $pdo->prepare(
    "SELECT id FROM etudiants WHERE email = ? AND promotion_id = ?"
);
$stmt->execute([$email, $promotion_id]);

echo json_encode([
    "exists" => $stmt->rowCount() > 0
]);
