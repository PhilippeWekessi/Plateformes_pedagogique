<?php
require_once "../../config/database.php";

$nom = $_POST['nom'];
$prenom = $_POST['prenom'];
$email = $_POST['email'];
$promotion_id = $_POST['promotion_id'];

// Vérifier si étudiant existe déjà
$check = $pdo->prepare(
    "SELECT id FROM etudiants WHERE email = ? AND promotion_id = ?"
);
$check->execute([$email, $promotion_id]);

if ($check->rowCount() > 0) {
    echo json_encode([
        "success" => false,
        "message" => "Étudiant déjà existant"
    ]);
    exit;
}

// Insertion
$stmt = $pdo->prepare(
    "INSERT INTO etudiants (nom, prenom, email, promotion_id)
     VALUES (?, ?, ?, ?)"
);

$stmt->execute([$nom, $prenom, $email, $promotion_id]);

// Simulation email
// mail($email, "Activation", "Activez votre compte étudiant");

echo json_encode([
    "success" => true,
    "message" => "Étudiant créé avec succès. Email envoyé."
]);
