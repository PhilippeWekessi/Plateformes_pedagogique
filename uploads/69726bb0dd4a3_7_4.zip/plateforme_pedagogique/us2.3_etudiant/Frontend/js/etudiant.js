document.getElementById("formEtudiant").addEventListener("submit", e => {
    e.preventDefault();

    const data = new FormData(e.target);

    fetch("../backend/creer_etudiant.php", {
        method: "POST",
        body: data
    })
    .then(res => res.json())
    .then(res => {
        const msg = document.getElementById("message");
        msg.textContent = res.message;
        msg.className = res.success ? "success" : "error";
    });
});
