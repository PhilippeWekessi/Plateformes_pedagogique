<?php
// Détection automatique de l'environnement
if ($_SERVER['HTTP_HOST'] == 'localhost' || $_SERVER['HTTP_HOST'] == '127.0.0.1') {
    // Configuration LOCAL
    $host = "localhost";
    $dbname = "plateforme_pedagogique_db";
    $user = "root";
    $pass = "";
} else {
    // Configuration INFINITYFREE (PRODUCTION)
    $host = "sql210.infinityfree.com";
    $dbname = "if0_40935720_plateforme";
    $user = "if0_40935720";
    $pass = "wekessiphilippe";
}

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8",
        $user,
        $pass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]
    );
} catch (PDOException $e) {
    echo json_encode([
        "success" => false,
        "message" => "Erreur connexion base de données"
    ]);
    exit;
}
?>