document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("formAffectation");
    const message = document.getElementById("message");

    form.addEventListener("submit", (e) => {
        e.preventDefault();

        const etudiant_id = document.getElementById("etudiant").value;
        const espace_id = document.getElementById("espace").value;

        fetch("../backend/verifier_affectation.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                etudiant_id: etudiant_id,
                espace_id: espace_id
            })
        })
        .then(res => res.json())
        .then(data => {
            message.innerText = data.message;
            message.style.color = data.success ? "green" : "red";
        })
        .catch(() => {
            message.innerText = "Erreur serveur";
            message.style.color = "red";
        });
    });
});
