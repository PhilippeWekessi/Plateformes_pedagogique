<?php
require_once "../../config/database.php";

$id_etudiant = $_POST['id_etudiant'] ?? null;
$id_espace = $_POST['id_espace'] ?? null;

if (!$id_etudiant || !$id_espace) {
    echo json_encode(["status" => "error", "message" => "Informations manquantes"]);
    exit;
}

try {
    $sql = "INSERT INTO etudiant_espace (id_etudiant, id_espace)
            VALUES (:etudiant, :espace)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ":etudiant" => $id_etudiant,
        ":espace" => $id_espace
    ]);

    echo json_encode(["status" => "success", "message" => "Étudiant ajouté avec succès"]);

} catch (PDOException $e) {
    echo json_encode([
        "status" => "error",
        "message" => "Étudiant déjà ajouté à cet espace pédagogique"
    ]);
}
