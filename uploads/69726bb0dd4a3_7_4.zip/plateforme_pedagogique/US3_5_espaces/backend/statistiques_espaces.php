<?php
session_start();
require_once "../../config/database.php";

$stats = [];

$stats['total_espaces'] = $pdo->query(
    "SELECT COUNT(*) FROM espaces_pedagogiques"
)->fetchColumn();

$stats['total_etudiants'] = $pdo->query(
    "SELECT COUNT(*) FROM etudiants"
)->fetchColumn();

$stats['total_formateurs'] = $pdo->query(
    "SELECT COUNT(*) FROM formateurs"
)->fetchColumn();

echo json_encode($stats);
