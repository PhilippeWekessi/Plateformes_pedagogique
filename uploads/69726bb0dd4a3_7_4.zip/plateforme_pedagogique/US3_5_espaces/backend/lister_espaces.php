<?php
session_start();
require_once "../../config/database.php";

/* Vérification rôle directeur */
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'directeur') {
    http_response_code(403);
    echo json_encode([]);
    exit;
}

$sql = "
SELECT 
    e.nom_espace,
    p.libelle AS promotion,
    CONCAT(f.nom, ' ', f.prenom) AS formateur,
    COUNT(et.id_etudiant) AS nombre_etudiants
FROM espaces_pedagogiques e
LEFT JOIN promotions p ON e.id_promotion = p.id_promotion
LEFT JOIN formateurs f ON e.id_formateur = f.id_formateur
LEFT JOIN etudiants et ON p.id_promotion = et.id_promotion
GROUP BY e.id_espace
";

$stmt = $pdo->query($sql);
$resultats = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($resultats);
