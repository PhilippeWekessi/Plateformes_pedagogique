document.addEventListener("DOMContentLoaded", () => {
    chargerEspaces();
    chargerStats();
});

function chargerEspaces() {
    fetch("../backend/lister_espaces.php")
        .then(res => res.json())
        .then(data => {
            const tbody = document.querySelector("#tableEspaces tbody");
            const message = document.getElementById("message");
            tbody.innerHTML = "";

            if (data.length === 0) {
                message.textContent = 
                    "Aucun espace pédagogique n’est enregistré. Veuillez en créer un.";
                return;
            }

            message.textContent = "";

            data.forEach(espace => {
                const row = `
                    <tr>
                        <td>${espace.nom_espace}</td>
                        <td>${espace.promotion}</td>
                        <td>${espace.formateur}</td>
                        <td>${espace.nombre_etudiants}</td>
                    </tr>`;
                tbody.innerHTML += row;
            });
        });
}

function chargerStats() {
    fetch("../backend/statistiques_espaces.php")
        .then(res => res.json())
        .then(stats => {
            const ul = document.getElementById("stats");
            ul.innerHTML = `
                <li>Total espaces : ${stats.total_espaces}</li>
                <li>Total étudiants : ${stats.total_etudiants}</li>
                <li>Total formateurs : ${stats.total_formateurs}</li>
            `;
        });
}
