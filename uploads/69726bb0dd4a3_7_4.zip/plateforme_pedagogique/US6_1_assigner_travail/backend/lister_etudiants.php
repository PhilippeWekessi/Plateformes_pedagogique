<?php
require_once "../../config/database.php";

$stmt = $pdo->query("SELECT id_etudiant, nom, prenom FROM etudiants");
echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
