<?php
session_start();
require_once "../../config/database.php";

$data = json_decode(file_get_contents("php://input"), true);

if (
    empty($data['etudiant']) ||
    empty($data['titre']) ||
    empty($data['consignes']) ||
    empty($data['date_limite'])
) {
    echo json_encode([
        "success" => false,
        "message" => "Veuillez remplir tous les champs obligatoires."
    ]);
    exit;
}

$sql = "INSERT INTO travaux 
(titre, type_travail, consignes, date_limite, id_formateur, id_etudiant)
VALUES (?, ?, ?, ?, ?, ?)";

$stmt = $pdo->prepare($sql);
$stmt->execute([
    $data['titre'],
    $data['type'],
    $data['consignes'],
    $data['date_limite'],
    $_SESSION['id_user'], // formateur connecté
    $data['etudiant']
]);

echo json_encode([
    "success" => true,
    "message" => "Travail assigné avec succès."
]);
