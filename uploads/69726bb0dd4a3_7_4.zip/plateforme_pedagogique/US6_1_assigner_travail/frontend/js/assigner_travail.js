document.addEventListener("DOMContentLoaded", chargerEtudiants);

function chargerEtudiants() {
    fetch("../backend/lister_etudiants.php")
        .then(res => res.json())
        .then(data => {
            const select = document.getElementById("etudiant");
            select.innerHTML = "<option value=''>-- Choisir un étudiant --</option>";

            data.forEach(e => {
                select.innerHTML += `
                    <option value="${e.id_etudiant}">
                        ${e.nom} ${e.prenom}
                    </option>`;
            });
        });
}

document.getElementById("formTravail").addEventListener("submit", e => {
    e.preventDefault();

    const data = {
        etudiant: etudiant.value,
        titre: titre.value,
        type: type.value,
        consignes: consignes.value,
        date_limite: date_limite.value
    };

    fetch("../backend/assigner_travail.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    })
    .then(res => res.json())
    .then(result => {
        const msg = document.getElementById("message");
        msg.style.color = result.success ? "green" : "red";
        msg.textContent = result.message;
    });
});
