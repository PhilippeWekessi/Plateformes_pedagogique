<?php
require_once "../../config/database.php";

$sql = "
SELECT l.id_livraison, t.titre,
       CONCAT(e.nom, ' ', e.prenom) AS etudiant
FROM livraisons l
JOIN travaux t ON l.id_travail = t.id_travail
JOIN etudiants e ON l.id_etudiant = e.id_etudiant
LEFT JOIN evaluations ev ON l.id_livraison = ev.id_livraison
WHERE ev.id_livraison IS NULL
";

$stmt = $pdo->query($sql);
echo json_encode($stmt->fetchAll());
