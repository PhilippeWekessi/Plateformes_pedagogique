<?php
session_start();
require_once "../../config/database.php";

$data = json_decode(file_get_contents("php://input"), true);

if (
    empty($data['livraison']) ||
    empty($data['note']) ||
    empty($data['commentaire'])
) {
    echo json_encode([
        "success" => false,
        "message" => "Veuillez renseigner tous les champs."
    ]);
    exit;
}

$sql = "INSERT INTO evaluations 
(id_livraison, note, commentaire, id_formateur)
VALUES (?, ?, ?, ?)";

$stmt = $pdo->prepare($sql);
$stmt->execute([
    $data['livraison'],
    $data['note'],
    $data['commentaire'],
    $_SESSION['id_user']
]);

echo json_encode([
    "success" => true,
    "message" => "Évaluation enregistrée avec succès."
]);
