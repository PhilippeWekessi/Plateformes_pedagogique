document.addEventListener("DOMContentLoaded", chargerTravauxLivres);

function chargerTravauxLivres() {
    fetch("../backend/lister_travaux_livres.php")
        .then(res => res.json())
        .then(data => {
            const select = document.getElementById("livraison");
            select.innerHTML = "<option value=''>-- Choisir un travail livré --</option>";

            data.forEach(t => {
                select.innerHTML += `
                    <option value="${t.id_livraison}">
                        ${t.titre} - ${t.etudiant}
                    </option>`;
            });
        });
}

document.getElementById("formEvaluation").addEventListener("submit", e => {
    e.preventDefault();

    const data = {
        livraison: livraison.value,
        note: note.value,
        commentaire: commentaire.value
    };

    fetch("../backend/evaluer_travail.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    })
    .then(res => res.json())
    .then(result => {
        const msg = document.getElementById("message");
        msg.style.color = result.success ? "green" : "red";
        msg.textContent = result.message;
    });
});
