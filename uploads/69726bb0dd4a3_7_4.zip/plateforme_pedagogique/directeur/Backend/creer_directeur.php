<?php
header("Content-Type: application/json");
require_once "verifier_session.php";
require_once "connexion.php"; // ton fichier PDO

$nom = $_POST['nom'] ?? '';
$prenom = $_POST['prenom'] ?? '';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

if (!$nom || !$prenom || !$email || !$password) {
    echo json_encode(["success" => false, "message" => "Champs obligatoires manquants"]);
    exit;
}

$hash = password_hash($password, PASSWORD_DEFAULT);

$sql = "INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, role)
        VALUES (?, ?, ?, ?, 'directeur')";

$stmt = $pdo->prepare($sql);

try {
    $stmt->execute([$nom, $prenom, $email, $hash]);
    echo json_encode(["success" => true, "message" => "Compte directeur créé avec succès"]);
} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => "Email déjà utilisé"]);
}
