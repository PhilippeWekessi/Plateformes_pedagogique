document.getElementById("formDirecteur").addEventListener("submit", function (e) {
    e.preventDefault();

    const formData = new FormData(this);

    fetch("../backend/creer_directeur.php", {
        method: "POST",
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        const message = document.getElementById("message");
        message.textContent = data.message;
        message.className = data.success ? "success" : "error";
    })
    .catch(() => {
        document.getElementById("message").textContent = "Erreur réseau ou serveur";
    });
});
